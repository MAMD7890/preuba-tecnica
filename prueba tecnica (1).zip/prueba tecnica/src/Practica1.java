import java.util.Scanner;

public class Practica1 {
	public static void main(String[] args)
	{
		Scanner scanner = new Scanner(System.in);
		System.out.println("Ingrese un número entero:");
		int numero = scanner.nextInt();
		while (numero < 0 || numero > 100)
		{
			System.out.println("El número debe estar dentro del rango 1 a 100 ");
			numero = scanner.nextInt();
		}
		if (numero >= 1 && numero <= 100)
		{
			if (numero % 2 == 1)
			{
				System.out.println("Quipux");
			}
			else
			{
				if (numero >= 2 && numero <= 5)
				{
					System.out.println("No Quipux");
				}
				else if (numero >= 6 && numero <= 20)
				{
					System.out.println("Quipux");
				}
				else
				{
					System.out.println("No Quipux");
				}
			}

		}
	}
}

