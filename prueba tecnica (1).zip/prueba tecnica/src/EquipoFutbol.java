import java.util.ArrayList;
import java.util.List;
class EquipoFutbol{
	private String nombreEquipo;
	private String estadio;
	private int cantidadTitulos;
	private List<Jugador> titulares;
	private List<Jugador> suplentes;

	public EquipoFutbol(String nombreEquipo, String estadio, int cantidadTitulos) {
		this.nombreEquipo = nombreEquipo;
		this.estadio = estadio;
		this.cantidadTitulos = cantidadTitulos;
		this.titulares = new ArrayList<>();
		this.suplentes = new ArrayList<>();
	}

	public void agregarTitular(Jugador jugador) {
		titulares.add(jugador);
	}

	public void agregarSuplente(Jugador jugador) {
		suplentes.add(jugador);
	}

	public void generarReporteBasico() {
		System.out.println("reporte Básico:");
		System.out.println("nombre del equipo: " + nombreEquipo);
		System.out.println("títulos ganados: " + cantidadTitulos);
		System.out.println("cantidad total de jugadores: " + (titulares.size() + suplentes.size()));
	}

	public void generarReporteDetallado() {
		System.out.println("reporte Detallado:");
		System.out.println("nombre del equipo: " + nombreEquipo);
		System.out.println("estadio: " + estadio);
		System.out.println("títullos ganados: " + cantidadTitulos);

		System.out.println("titulares:");
		for (Jugador titular : titulares) {
			System.out.println("nombre: " + titular.getNombre() + ", posición: " + titular.getPosicion());
		}

		System.out.println("suplentes:");
		for (Jugador suplente : suplentes) {
			System.out.println("nombre: " + suplente.getNombre() + ", Posición: " + suplente.getPosicion());
		}
	}
}


