import java.util.Scanner;

public class Programa2{
	public static void main (String[] args) {
		Scanner scanner = new Scanner(System.in);

		System.out.print("ingrese el nombre del equipo: ");
		String nombreEquipo = scanner.nextLine();
		System.out.print("ingrese el estadio del equipo: ");
		String estadio = scanner.nextLine();
		System.out.print("ingrese la cantidad de títulos: ");
		int cantidadTitulos = scanner.nextInt();
		scanner.nextLine();

		EquipoFutbol equipo = new EquipoFutbol(nombreEquipo, estadio, cantidadTitulos);
		while (true)
		{
			System.out.println("\nseleccione una opción:");
			System.out.println("1. agregar jugador titular");
			System.out.println("2. agregar jugador suplente");
			System.out.println("3. generar reporte básico");
			System.out.println("4. generar reporte detallado");
			System.out.println("5. Salir");

			int opcion = scanner.nextInt();
			scanner.nextLine();

			switch (opcion)
			{
				case 1:
					System.out.print("ingrese el nombre del jugador titular: ");
					String nombreTitular = scanner.nextLine();
					System.out.print("ingrese la posición del jugador titular: ");
					String posicionTitular = scanner.nextLine();
					Jugador titular = new Jugador(nombreTitular, posicionTitular);
					equipo.agregarTitular(titular);
					break;
				case 2:
					System.out.print("ingrese el nombre del jugador suplente: ");
					String nombreSuplente = scanner.nextLine();
					System.out.print("ingrese la posición del jugador suplente: ");
					String posicionSuplente = scanner.nextLine();
					Jugador suplente = new Jugador(nombreSuplente, posicionSuplente);
					equipo.agregarSuplente(suplente);
					break;
				case 3:
					equipo.generarReporteBasico();
					break;
				case 4:
					equipo.generarReporteDetallado();
					break;
				case 5:
					System.exit(0);
				default:
					System.out.println("Opción no válida :(. seleccione una opción válida :).");
			}
		}
	}
}


