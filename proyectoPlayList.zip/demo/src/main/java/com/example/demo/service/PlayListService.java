package com.example.demo.service;

import com.example.demo.models.PlayList;
import com.example.demo.repository.PlayListRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PlayListService {
    @Autowired
    public PlayListRepository playListRepository;

    private Long id;

    public List<PlayList> getAllPlayList()
    {
        return playListRepository.findAll();

    }

    public PlayList getPlayListById(Long id)
    {
        return playListRepository.getById(id);

    }

    public PlayList updatePlayList(PlayList update, Long id)
    {
        PlayList playListDataBase=playListRepository.getById(id);
        if (playListDataBase!=null){
            return playListRepository.save(update);
        }
        return null;
    }
    public String deletePlayList(Long id)
    {
        PlayList playListDataBase=playListRepository.getById(id);
        if (playListDataBase!=null){
            playListRepository.delete(playListDataBase);
            return "Se elimino el registro con Exito.";
        }
        return "No Existe el ID dentro de la base de datos.";

    }
    public PlayList savePlaylist(PlayList saveForSave)
    {
        return playListRepository.save(saveForSave);

    }
}
