package com.example.demo.models;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Entity
@Table(name = "playlist")
public class PlayList {

    @Id
    @Getter
    @Setter
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "idplay_list")
    private Long id;

    @ManyToMany
    @JoinTable(
            name="play_song",
            joinColumns = @JoinColumn(name = "playlist_id"),
            inverseJoinColumns = @JoinColumn(name = "song_id")


    )
    @Getter
    @Setter
    private List<Song>songs;

    @Column(name ="name_playlist")
    @Getter
    @Setter
    private String NamePlayList;

    @Column(name =" ")
    @Getter
    @Setter
    private String Description;

}
