package com.example.demo.controllers;


import com.example.demo.models.PlayList;
import com.example.demo.service.PlayListService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(value = "/api/playlist", produces = MediaType.APPLICATION_JSON_VALUE)
@CrossOrigin(origins = "*")
public class PlayListController
{

    @Autowired
    private PlayListService playListService;

    @GetMapping(path = "/all", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public List<PlayList> getAllPlaylist()
    {
        return playListService.getAllPlayList();
    }

    @GetMapping(path = "/{id}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public PlayList getSongById(@PathVariable(name = "id") Long id)
    {
        return playListService.getPlayListById(id);

    }

    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public PlayList savePlaylist(@RequestBody PlayList playList)
    {
        return playListService.savePlaylist(playList);


    }
    @PutMapping(path = "/{id}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public PlayList updatePlayList(@PathVariable(name = "id") Long id, @RequestBody PlayList update)
    {
        return playListService.updatePlayList(update, id);
    }


    @DeleteMapping(path = "/{id}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public String deletePlayList(@PathVariable(name = "id") Long id)
    {
        return playListService.deletePlayList(id);

    }
}